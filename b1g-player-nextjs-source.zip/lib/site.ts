export const siteConfig = {
  name: "B1G IPTV",
  shortName: "B1G",
  description:
    "Premium IPTV subscriptions, B1G Player setup guides, reseller opportunities, and fast customer support.",
  url: process.env.NEXT_PUBLIC_SITE_URL || "https://b1g-player-clone.cheeky-scout-7926.chatgpt.site",
  email: "b1giptvus@gmail.com",
  whatsappNumber: "15551234567",
  telegramUrl: "https://t.me/",
  logoUrl:
    "https://b1gplayer.us/wp-content/uploads/elementor/thumbs/B1G-IPTV-rif7xmhqov5yjls229vbcs2orphywpcgc32423w0tc.png",
  deviceImageUrl:
    "https://b1gplayer.us/wp-content/uploads/2025/11/ways-to-stream-devices-1.webp",
};

export const navItems = [
  { label: "Home", href: "/" },
  { label: "Pricing", href: "/#pricing" },
  { label: "Reseller Panel", href: "/b1g-iptv-reseller-panel" },
  { label: "Installation Guide", href: "/b1g-iptv-installation-guide" },
  {
    label: "B1G Player",
    href: "/b1g-iptv-player-app-latest-version-for-android-firestick",
  },
  { label: "Contact", href: "/contact-b1g-iptv" },
  { label: "Blogs", href: "/blogs" },
];

export function whatsappUrl(message = "Hi, I would like to know more about B1G IPTV.") {
  return `https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

export type Plan = {
  duration: string;
  price: number;
  recommended?: boolean;
  features: string[];
};

export const plans: Record<"standard" | "premium", Plan[]> = {
  standard: [
    {
      duration: "1 Year",
      price: 60,
      recommended: true,
      features: [
        "Free 6 Hours Test",
        "9,000+ Channels",
        "39,000+ VODs",
        "5,000+ Series",
        "HD & 4K Quality",
        "All Devices Support",
      ],
    },
    {
      duration: "6 Months",
      price: 40,
      features: [
        "Free 6 Hours Test",
        "9,000+ Channels",
        "39,000+ VODs",
        "5,000+ Series",
        "HD & 4K Quality",
        "All Devices Support",
      ],
    },
    {
      duration: "3 Months",
      price: 25,
      features: [
        "Free 6 Hours Test",
        "9,000+ Channels",
        "39,000+ VODs",
        "5,000+ Series",
        "HD & 4K Quality",
        "All Devices Support",
      ],
    },
    {
      duration: "1 Month",
      price: 15,
      features: [
        "Free 6 Hours Test",
        "9,000+ Channels",
        "39,000+ VODs",
        "5,000+ Series",
        "HD & 4K Quality",
        "All Devices Support",
      ],
    },
  ],
  premium: [
    {
      duration: "1 Year",
      price: 90,
      recommended: true,
      features: [
        "Free 6 Hours Test",
        "9,000+ Channels",
        "Higher Quality (4K UHD)",
        "More Stable Connection",
        "Less Downtime",
        "3× More VODs than Standard",
      ],
    },
    {
      duration: "6 Months",
      price: 60,
      features: [
        "Free 6 Hours Test",
        "9,000+ Channels",
        "Higher Quality (4K UHD)",
        "More Stable Connection",
        "Less Downtime",
        "3× More VODs than Standard",
      ],
    },
    {
      duration: "3 Months",
      price: 35,
      features: [
        "Free 6 Hours Test",
        "9,000+ Channels",
        "Higher Quality (4K UHD)",
        "More Stable Connection",
        "Less Downtime",
        "3× More VODs than Standard",
      ],
    },
    {
      duration: "1 Month",
      price: 20,
      features: [
        "Free 6 Hours Test",
        "9,000+ Channels",
        "Higher Quality (4K UHD)",
        "More Stable Connection",
        "Less Downtime",
        "3× More VODs than Standard",
      ],
    },
  ],
};

export const commonFaqs = [
  {
    question: "What is B1G IPTV?",
    answer:
      "B1G IPTV delivers live TV, movies, and on-demand content over the internet in HD and 4K, without a traditional cable connection.",
  },
  {
    question: "Can I use IPTV on multiple devices?",
    answer:
      "Yes. The service works with Firestick, Android TV, Samsung and LG smart TVs, iOS, Windows, Mac, MAG boxes, and many other devices. Ask support about simultaneous connections.",
  },
  {
    question: "How many channels does B1G IPTV offer?",
    answer:
      "B1G IPTV provides thousands of live channels across sports, news, entertainment, kids, local USA, and international categories, plus a large video-on-demand library.",
  },
  {
    question: "What payment methods do you accept?",
    answer:
      "Available methods include credit or debit card, PayPal, Apple Pay, Google Pay, Revolut Pay, and cryptocurrency. Contact support to confirm the best option for your location.",
  },
];
