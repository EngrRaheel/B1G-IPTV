export type BlogSection = {
  heading: string;
  paragraphs?: string[];
  bullets?: string[];
  steps?: { title: string; text: string }[];
};

export type BlogPost = {
  slug: string;
  title: string;
  metaTitle: string;
  description: string;
  excerpt: string;
  label: string;
  publishedAt: string;
  updatedAt: string;
  sections: BlogSection[];
};

export const blogPosts: BlogPost[] = [
  {
    slug: "how-to-watch-nfl-on-b1g-iptv",
    title: "How to Watch NFL on B1G IPTV",
    metaTitle: "How to Watch NFL on B1G IPTV",
    description:
      "Learn how to set up B1G IPTV for NFL games, which devices are supported, and how to find live football channels.",
    excerpt:
      "A practical setup guide for watching regular-season NFL games, playoffs, and the Super Bowl across your favorite devices.",
    label: "NFL",
    publishedAt: "2026-01-27",
    updatedAt: "2026-06-20",
    sections: [
      {
        heading: "Why choose B1G IPTV for NFL?",
        paragraphs: [
          "Football fans need a service that is easy to access and reliable during high-traffic games. B1G IPTV combines flexible plans with broad device support and dedicated help when you need it.",
        ],
        bullets: [
          "Regular season, playoffs, and major NFL events",
          "HD and 4K options without a cable box",
          "Support for smart TVs, phones, computers, and Fire TV devices",
          "Stable servers designed to reduce interruptions",
        ],
      },
      {
        heading: "Popular NFL channels",
        paragraphs: [
          "Available channel lineups can include ESPN, NFL Network, FOX, CBS, NBC, and ABC. Contact support before subscribing if a specific regional channel matters to you.",
        ],
      },
      {
        heading: "How to start watching",
        steps: [
          { title: "Choose a plan", text: "Select the subscription length and stream quality you prefer." },
          { title: "Receive your details", text: "Your activation message includes an M3U link or Xtream Codes login." },
          { title: "Install a player", text: "Use B1G Player or a compatible app on your device." },
          { title: "Open the sports category", text: "Choose the NFL channel carrying your game and start streaming." },
        ],
      },
      {
        heading: "Supported devices",
        bullets: ["Samsung, LG, and Android smart TVs", "Firestick and Fire TV", "Android and iOS phones", "Windows and Mac computers", "MAG boxes"],
      },
    ],
  },
  {
    slug: "watch-ufc-wwe-boxing-ppv-on-b1g-iptv",
    title: "How to Watch UFC, WWE, Boxing & Other PPV Events",
    metaTitle: "Watch UFC, WWE, Boxing & PPV Live",
    description:
      "Set up B1G IPTV to watch UFC, WWE, boxing, and other pay-per-view events in HD or 4K on supported devices.",
    excerpt:
      "Follow major fight nights, wrestling events, boxing cards, and other live PPV programming with one simple setup.",
    label: "PPV",
    publishedAt: "2026-01-27",
    updatedAt: "2026-06-20",
    sections: [
      {
        heading: "What counts as a PPV event?",
        paragraphs: [
          "Pay-per-view programming includes premium live events that are normally sold separately. Typical categories include UFC cards, major boxing fights, WWE premium events, AEW shows, and other combat-sports broadcasts.",
        ],
      },
      {
        heading: "Why use B1G IPTV for live events?",
        bullets: [
          "One subscription instead of separate purchases for every event",
          "HD, Full HD, and 4K channel options",
          "Access on TVs, mobile devices, Firestick, and computers",
          "A dedicated sports and PPV category for easier browsing",
        ],
      },
      {
        heading: "Set up your PPV stream",
        steps: [
          { title: "Activate a subscription", text: "Choose a B1G IPTV plan before the event date." },
          { title: "Install your preferred app", text: "Use B1G Player, IPTV Smarters, TiviMate, XCIPTV, or another compatible player." },
          { title: "Enter your credentials", text: "Add the M3U or Xtream Codes details sent after activation." },
          { title: "Find the event", text: "Open PPV, combat sports, or live sports shortly before the broadcast begins." },
        ],
      },
    ],
  },
  {
    slug: "watch-nba-mlb-live-on-b1g-iptv-us",
    title: "How to Watch NBA & MLB Live on B1G IPTV",
    metaTitle: "Watch NBA & MLB Live on B1G IPTV",
    description:
      "A quick guide to streaming NBA and MLB games with B1G IPTV on smart TVs, Firestick, phones, and computers.",
    excerpt:
      "Catch basketball and baseball action, from the regular season to the finals and World Series, on the devices you already own.",
    label: "NBA + MLB",
    publishedAt: "2026-01-27",
    updatedAt: "2026-06-20",
    sections: [
      {
        heading: "Basketball and baseball in one place",
        paragraphs: [
          "B1G IPTV organizes major sports networks into a single channel list, making it easier to move between live NBA and MLB broadcasts without changing subscriptions or devices.",
        ],
        bullets: ["Regular-season games and playoffs", "NBA Finals and World Series coverage", "HD and 4K stream options", "Support for multiple device types"],
      },
      {
        heading: "How to watch",
        steps: [
          { title: "Subscribe", text: "Choose the plan length and service tier that fit your schedule." },
          { title: "Install an IPTV player", text: "Set up B1G Player or another compatible application." },
          { title: "Log in", text: "Enter your M3U link or Xtream Codes username and password." },
          { title: "Choose your game", text: "Open the sports list and select the channel before tip-off or first pitch." },
        ],
      },
      {
        heading: "Compatible devices",
        bullets: ["Smart TVs", "Firestick and Fire TV", "Android and iOS", "MAG boxes", "Windows and Mac"],
      },
    ],
  },
  {
    slug: "watch-nhl-mls-live-on-b1g-iptv-us",
    title: "How to Watch NHL & MLS Live on B1G IPTV",
    metaTitle: "Watch NHL & MLS Live on B1G IPTV",
    description:
      "Learn how to stream NHL and MLS games with B1G IPTV in HD or 4K on TVs, mobile devices, Firestick, Windows, and Mac.",
    excerpt:
      "A straightforward guide for finding live hockey and soccer broadcasts and setting up a compatible IPTV player.",
    label: "NHL + MLS",
    publishedAt: "2026-01-27",
    updatedAt: "2026-06-20",
    sections: [
      {
        heading: "Follow every goal and puck drop",
        paragraphs: [
          "B1G IPTV offers access to sports categories that can carry NHL and MLS broadcasts across the regular season and playoffs. Check the current lineup with support if you need a particular local network.",
        ],
        bullets: ["NHL regular season, playoffs, and Stanley Cup", "MLS regular season, playoffs, and MLS Cup", "HD, Full HD, and 4K options", "Broad device compatibility"],
      },
      {
        heading: "Set up your stream",
        steps: [
          { title: "Select a subscription", text: "Choose a plan and request activation from the support team." },
          { title: "Install a player", text: "Use B1G Player or a compatible app on your preferred screen." },
          { title: "Add your account", text: "Sign in with the details supplied after purchase." },
          { title: "Open live sports", text: "Select the hockey or soccer category and choose your channel." },
        ],
      },
      {
        heading: "Where you can watch",
        bullets: ["Samsung, LG, and Android smart TVs", "Firestick and Fire TV", "Android and iOS devices", "Windows and Mac", "MAG boxes"],
      },
    ],
  },
];

export function getBlogPost(slug: string) {
  return blogPosts.find((post) => post.slug === slug);
}
